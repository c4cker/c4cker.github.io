window.runtime = { diagnosticsKey: 'amber-echo', token: 'C4CKER{176610f472288893629d5c6bab7844cc}' };

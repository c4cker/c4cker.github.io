window.runtime = { diagnosticsKey: 'amber-echo', token: 'C4CKER{5915693809b442e2acd66be16b028746}' };

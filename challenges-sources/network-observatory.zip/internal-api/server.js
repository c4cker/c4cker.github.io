const http = require('http');
const reply = (res, code, body) => { res.writeHead(code, {'content-type':'application/json'}); res.end(JSON.stringify(body)); };
http.createServer((req,res) => {
  if (req.url === '/status') return reply(res,200,{service:'internal-api',operator:'northstar',next:'/operator'});
  if (req.url === '/operator' && req.headers['x-observatory-key'] === 'northstar') return reply(res,200,{token:'C4CKER{87b866aa6bf742049044e0daefc31bea}',next:'/completion',trace:'7c-18-ef'});
  if (req.url === '/completion' && req.headers['x-session-trace'] === '7c-18-ef') return reply(res,200,{token:'C4CKER{25228d8e49644c78b61a8de111d21acf}'});
  return reply(res,404,{error:'not_found'});
}).listen(3000);

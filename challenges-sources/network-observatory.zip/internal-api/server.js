const http = require('http');
const reply = (res, code, body) => { res.writeHead(code, {'content-type':'application/json'}); res.end(JSON.stringify(body)); };
http.createServer((req,res) => {
  if (req.url === '/status') return reply(res,200,{service:'internal-api',operator:'northstar',next:'/operator'});
  if (req.url === '/operator' && req.headers['x-observatory-key'] === 'northstar') return reply(res,200,{token:'C4CKER{d8ac1f027ae2bea113375c87dc905441}',next:'/completion',trace:'7c-18-ef'});
  if (req.url === '/completion' && req.headers['x-session-trace'] === '7c-18-ef') return reply(res,200,{token:'C4CKER{1a2ce69163ed2e16f8e7bd592da9a794}'});
  return reply(res,404,{error:'not_found'});
}).listen(3000);

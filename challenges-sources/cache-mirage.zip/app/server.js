const http = require('http');
const send=(res,code,body)=>{res.writeHead(code,{'content-type':'application/json','cache-control':'public, max-age=60'});res.end(JSON.stringify(body));};
http.createServer((req,res)=>{
  if(req.url==='/') return send(res,200,{challenge:'Cache Mirage',routes:['/digest','/preview','/final']});
  if(req.url==='/digest' && req.headers['x-lab-role']==='analyst') return send(res,200,{token:'C4CKER{89d19561a03646fa9e343cc9938d7502}',hint:'preview uses X-Preview: violet'});
  if(req.url==='/preview' && req.headers['x-preview']==='violet') return send(res,200,{token:'C4CKER{52de8c2120ec4388b93b8c8fa81269b2}',hint:'final uses X-Review: cache-miss'});
  if(req.url==='/final' && req.headers['x-review']==='cache-miss') return send(res,200,{token:'C4CKER{268c63ec6c794d928d6bf9d8378cc87d}'});
  return send(res,404,{error:'not_found'});
}).listen(3000);

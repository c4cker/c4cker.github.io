const http = require('http');
const send=(res,code,body)=>{res.writeHead(code,{'content-type':'application/json','cache-control':'public, max-age=60'});res.end(JSON.stringify(body));};
http.createServer((req,res)=>{
  if(req.url==='/') return send(res,200,{challenge:'Cache Mirage',routes:['/digest','/preview','/final']});
  if(req.url==='/digest' && req.headers['x-lab-role']==='analyst') return send(res,200,{token:'C4CKER{a20269d66e00011040be49e2935716c4}',hint:'preview uses X-Preview: violet'});
  if(req.url==='/preview' && req.headers['x-preview']==='violet') return send(res,200,{token:'C4CKER{a4ed6c2190ea03b571550ce9c3647453}',hint:'final uses X-Review: cache-miss'});
  if(req.url==='/final' && req.headers['x-review']==='cache-miss') return send(res,200,{token:'C4CKER{b5028b0e9ed75d7acb2a0071ad25bfcd}'});
  return send(res,404,{error:'not_found'});
}).listen(3000);
